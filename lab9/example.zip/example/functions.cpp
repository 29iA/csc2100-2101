/*
	Title: functions.cpp
	....
*/

#include "jellybean.h"

int* makeArray(int n)
{
	int *arr;
	arr = new int[n];
	return arr;
}
void fillArray(int* arr, int n)
{
	for(int x=0; x < n; x++)
	{
		cout << "How many of flavor " << x+1 << " did you eat?  ";
		cin >> *(arr+x);
	}
}
void printArray(int* arr, int n)
{
	for(int x=0; x < n; x++)
	{
		cout << "FLAVOR " << (x+1) << ": " << *(arr+x) << endl;
	}
}