/*
	Title: jellybean.cpp
	....
*/

#include "jellybean.h"

int main()
{
	int * jellybeans;
	int numFlavors;
	
	cout << "\n\nHow many flavors of jellybeans do you have?\n";
	cin >> numFlavors;
	
	jellybeans = makeArray(numFlavors);
	cout << endl << endl;
	fillArray(jellybeans, numFlavors);
	cout << endl << endl;
	printArray(jellybeans, numFlavors);
	cout << endl << endl;
	return 0;
}