/*
	Title:  jellybean.h
	
*/
#ifndef _JELLYBEAN_H
#define _JELLYBEAN_H

#include <iostream>
using namespace std;

int* makeArray(int);
void fillArray(int*, int);
void printArray(int*, int);

#endif